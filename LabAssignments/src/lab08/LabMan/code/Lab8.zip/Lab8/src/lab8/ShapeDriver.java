package lab8;

import processing.core.*;

//The following line will not compile until you make the shapes package
import shapes.*;

public class ShapeDriver extends PApplet {

	private static final long serialVersionUID = 1L;

	public void setup()
	{
		size (200, 200);
		smooth();

		// your code here
	}

	public void draw()
	{
		background (127);

		// your code here
	}

	public static void main(String[] args) {
		PApplet.main(args);
		//Instantiate an object of the driver class.
		//Call the setup method on the above object.
		//Call the draw method on the above object.
	}

}
